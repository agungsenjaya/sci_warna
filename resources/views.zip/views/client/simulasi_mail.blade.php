{{ $name }}<br>
{{ $email }}<br>
{{ $nomor }}<br>
{{ $msg }}<br>